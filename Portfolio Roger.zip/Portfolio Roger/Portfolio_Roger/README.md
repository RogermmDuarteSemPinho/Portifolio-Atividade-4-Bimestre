# Portfólio Web — Roger Duarte

Projeto acadêmico desenvolvido do zero com HTML5, CSS3, JavaScript e Bootstrap 5, conforme o escopo da atividade final do 4º bimestre.

## Estrutura
- `index.html`: apresentação pessoal, formação e competências.
- `CH.html`, `CN.html`, `MAT.html`, `LING.html`: relação entre disciplinas do Ensino Médio e lógica de programação.
- `Cibersecurity.html`, `Blockchain.html`, `Robotica.html`, `EdgeComputing.html`: tendências tecnológicas.
- `Galeria.html`: projetos e atividades desenvolvidas.
- `Contato.html`: formulário e painel administrativo.
- `EstiloPort.css`: identidade visual responsiva.
- `script.js`: LocalStorage, carga de dados de teste e CRUD.
- `config.js`: configuração do EmailJS.

## Executar
Não é necessário banco de dados nem servidor PHP. Extraia a pasta e abra `index.html` no navegador. Para melhor compatibilidade, pode usar a extensão Live Server do VS Code.

## CRUD e registros de demonstração
Na primeira visita à página Contato, o JavaScript verifica a chave `roger_portfolio_messages_v1` no LocalStorage. Se ela ainda não existir, cria automaticamente 20 registros de demonstração em JSON. O painel permite listar, editar e excluir mensagens.
Para abrir o painel, clique em **Acesso administrativo** no fim da página Contato ou use `Ctrl + Shift + A`. Esse painel é apenas uma demonstração acadêmica: como tudo roda no navegador, não oferece autenticação ou proteção real. Os dados são locais ao navegador e podem ser apagados pelo usuário.

## Notificação de e-mail (EmailJS)
A integração foi preparada com EmailJS. Para ativar:
1. Crie uma conta e um serviço no EmailJS.
2. Crie um template que use as variáveis `from_name`, `from_email` e `message`.
3. Copie a Public Key, Service ID e Template ID para `config.js`, substituindo os valores de exemplo.
4. Faça um teste pela página Contato.
O formulário sempre salva a mensagem no LocalStorage. O envio de e-mail só é tentado quando os três identificadores reais estão configurados. Não coloque chaves privadas no JavaScript.

## Personalização antes da entrega
- Substitua o monograma `RD` pelo seu retrato, se quiser incluir uma foto pessoal.
- Revise as competências pessoais para refletirem exatamente suas experiências.
- As imagens da galeria apontam para links do SharePoint escolar e podem exigir login institucional. Se não abrirem para o avaliador, baixe os screenshots e salve-os numa pasta `img/`, atualizando os `src`.
- O enunciado pede links para repositórios originais. Eles não foram fornecidos no material recebido; acrescente os links reais aos respectivos projetos na galeria. Não foram inventados links.
- Publique no GitHub/GitLab e inclua o endereço do repositório na entrega do Teams.

## Tecnologias
HTML5 · CSS3 · Bootstrap 5 · JavaScript · LocalStorage API · EmailJS
