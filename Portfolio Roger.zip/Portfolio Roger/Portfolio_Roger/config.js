// Configure suas credenciais do EmailJS em https://www.emailjs.com/
// Não compartilhe chaves privadas. A Public Key é própria para uso no navegador.
window.PORTFOLIO_CONFIG = {
  emailjsPublicKey: "jCDG7JP87pNwoXzHT",
  emailjsServiceId: "SEU_SERVICE_ID",
  emailjsTemplateId: "SEU_TEMPLATE_ID"
};
