(() => {
  const KEY = "roger_portfolio_messages_v1";
  const $ = (id) => document.getElementById(id);
  const config = window.PORTFOLIO_CONFIG || {};
  const hasEmailConfig = () => config.emailjsPublicKey && config.emailjsServiceId && config.emailjsTemplateId &&
    ![config.emailjsPublicKey,config.emailjsServiceId,config.emailjsTemplateId].some(v => String(v).startsWith("SUA_") || String(v).startsWith("SEU_"));
  function seedMessages() {
    if (localStorage.getItem(KEY) !== null) return;
    const samples = Array.from({length:20}, (_,i) => ({
      id: Date.now()+i, nome:`Visitante de teste ${i+1}`,
      email:`visitante${i+1}@exemplo.com`,
      mensagem:`Esta é uma mensagem demonstrativa de teste ${i+1}.`,
      data:new Date(Date.now()-i*3600000).toISOString(), teste:true
    }));
    localStorage.setItem(KEY, JSON.stringify(samples));
  }
  function getMessages() {
    try { const data=JSON.parse(localStorage.getItem(KEY)||"[]"); return Array.isArray(data)?data:[]; }
    catch { return []; }
  }
  function saveMessages(data) { localStorage.setItem(KEY,JSON.stringify(data)); }
  function el(tag, cls, text) { const node=document.createElement(tag); if(cls)node.className=cls; if(text!==undefined)node.textContent=text; return node; }
  const year=$("year"); if(year) year.textContent=new Date().getFullYear();
  const form=$("formContato");
  if(form) {
    seedMessages();
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const nome=$("nome").value.trim(), email=$("email").value.trim(), mensagem=$("mensagem").value.trim();
      const status=$("formStatus");
      if(!nome||!email||!mensagem){status.textContent="Preencha todos os campos.";return;}
      const data=getMessages();
      data.unshift({id:Date.now(),nome,email,mensagem,data:new Date().toISOString(),teste:false});
      saveMessages(data);
      status.textContent="Mensagem salva neste navegador.";
      if(hasEmailConfig()) {
        try {
          if(!window.emailjs) await new Promise((resolve,reject)=>{const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js";s.onload=resolve;s.onerror=reject;document.head.appendChild(s);});
          window.emailjs.init({publicKey:config.emailjsPublicKey});
          await window.emailjs.send(config.emailjsServiceId,config.emailjsTemplateId,{from_name:nome,from_email:email,message:mensagem});
          status.textContent="Mensagem salva e notificação enviada por e-mail.";
        } catch(err) { status.textContent="Mensagem salva localmente, mas o envio de e-mail falhou. Confira a configuração do EmailJS."; }
      } else {
        status.textContent="Mensagem salva localmente. Para receber e-mail, configure as credenciais do EmailJS em config.js.";
      }
      form.reset();
    });
  }
  const trigger=$("adminTrigger"), panel=$("adminPanel"), list=$("adminMessages");
  function renderAdmin() {
    if(!list)return;
    list.replaceChildren();
    const messages=getMessages();
    if(!messages.length){list.append(el("p","notice","Nenhuma mensagem cadastrada."));return;}
    messages.forEach(msg=>{
      const card=el("article","message-item");
      const heading=el("div","d-flex justify-content-between flex-wrap gap-2");
      heading.append(el("strong","",msg.nome||"Sem nome"));
      heading.append(el("small","notice",msg.data?new Date(msg.data).toLocaleString("pt-BR"):""));
      card.append(heading,el("div","notice",msg.email||""),el("p","mt-2 mb-2",msg.mensagem||""));
      if(msg.teste)card.append(el("span","tag","Registro de demonstração"));
      const actions=el("div","d-flex gap-2 mt-3");
      const edit=el("button","btn-small","Editar"), del=el("button","btn-small","Excluir");
      edit.type=del.type="button";
      edit.addEventListener("click",()=>{
        const name=prompt("Editar nome:",msg.nome); if(name===null)return;
        const email=prompt("Editar e-mail:",msg.email); if(email===null)return;
        const text=prompt("Editar mensagem:",msg.mensagem); if(text===null)return;
        const updated=getMessages().map(m=>m.id===msg.id?{...m,nome:name.trim(),email:email.trim(),mensagem:text.trim(),teste:false}:m);
        saveMessages(updated);renderAdmin();
      });
      del.addEventListener("click",()=>{
        if(!confirm("Excluir esta mensagem?"))return;
        saveMessages(getMessages().filter(m=>m.id!==msg.id));renderAdmin();
      });
      actions.append(edit,del);card.append(actions);list.append(card);
    });
  }
  function toggleAdmin(show) {
    if(!panel)return;
    panel.classList.toggle("open",show);
    if(trigger)trigger.setAttribute("aria-expanded",String(show));
    if(show)renderAdmin();
  }
  if(trigger)trigger.addEventListener("click",()=>toggleAdmin(!panel.classList.contains("open")));
  if($("closeAdmin"))$("closeAdmin").addEventListener("click",()=>toggleAdmin(false));
  // Atalho alternativo: Ctrl + Shift + A abre/fecha o painel local.
  document.addEventListener("keydown",e=>{if(e.ctrlKey&&e.shiftKey&&e.key.toLowerCase()==="a"&&panel){e.preventDefault();toggleAdmin(!panel.classList.contains("open"));}});
})();